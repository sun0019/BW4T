To run the human-artificial agent's simulation, follow the steps below:
1. Open the Goal, import bw4t.mas2g into the IDE. 
	Make sure myrobot.goal, writeMyOwn.goal, humanbot.goal, supAgent.goal and myHuman.goal are at the same directory as bw4t.mas2g.
2. To run the simplest scenario, click Run button and choose the minel map.

To configure  the costumed scenario:
Double click bw4t.mas2g.
	In bw4t.mas2g, agentfiles part:
	writeMyOwn.goal: artificial agent;
	Robot_KOEN.goal: the dummiest agent, for test purpose;
	humanbot.goal: human agent;
	myHuman.goal: human agent, the second scenario;
	supAgent.goal: supervisor agent, you have to wirte launchpolicy for supervisors.

	In launch policy part:
	You can have as many robots as you want.
	However, the launch policy have to match the conditions on the map.
	If you defined Bot1, Bot2 in the map, the agents named Bot1 and Bot2 can be launched.
	
